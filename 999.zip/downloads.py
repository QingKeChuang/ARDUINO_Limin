import APIS
import ID3ADD
import os
import ID3Convert
TrackList = """Geju - Niv (original mixe)
L'atto - Ali Farahani
Toot (Original Mix) - T-Puse
Miijetho (Original Mix) - M.ONDE
Avalos (Original Mix) - San Miguel
Shuro - Joep Mencke, Mâhfoud
Maar (Original Mix) - Kapoor
A Lama With No Name (Original Mix) - Richard Elcox, Matija
Close Your Eyes (Original Mix) - Nathan Hall
Gamechanger (Original Mix) - Feinheitsbrei
Heart (Original Mix) - Raidho
Modurai (Original Mix) - Zuma Dionys
Nebula (Original Mix) - Raw Main
El Corsario (Original Mix) - Kermesse
Mind Awake, Body Asleep (Original Mix) - Marco Tegui
The Happiness Equation (Original Mix) - The Oddness
Viva la vida (Original Mix) - Mom, ANuT, jPattersson
Planet X (Original Mix) - ÜNAM
Ualame Ualame (Original Mix) - Zuma Dionys"""
TrackList = TrackList.split("\n")
#base_path = "/Users/swipher/Music/set/"
#base_path = "/Users/swipher/Music/set/limin1111Downtempo"
base_path=''
download_path = base_path + input("Enter the download path: ")
command = input("Enter the command(1.Download TrackList\n2.Downloaded by Url): ")


def process_flac_files(Download_path):
    """处理文件夹中的 FLAC 文件并添加标签"""
    for root, dirs, files in os.walk(Download_path):
        files.sort(key=lambda f: os.path.getctime(os.path.join(root, f)))
        for file in files:
            if file.endswith(".flac"):
                flac_file_path = os.path.join(root, file)
                try:
                    os.mkdir(os.path.join(Download_path, "out"))
                except:
                    pass
                Output_path = os.path.join(root, "out", file)
                try:
                    ID3ADD.main(flac_file_path, Output_path)
                except:
                    pass


if command == "1":
    for i in TrackList:
        try:
            APIS.DownloadByName(download_path, i)
        except:
            pass
if command == "2":
    Url = input("Enter the URL: ")
    APIS.DownLoadByUrl(download_path, Url)
process_flac_files(download_path)
#process_flac_files('/Users/swipher/Music/set/limin1111/psytrance')
#ID3Convert.main(download_path)
#https://music.163.com/playlist?id=2337546782&userid=329081809
#https://music.163.com/song?id=2045386094&userid=329081809
#https://music.163.com/playlist?id=12916197023&userid=329081809
#https://music.163.com/#/song/1789168/?app_version=8.0.20

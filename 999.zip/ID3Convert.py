import os
from mutagen.flac import FLAC
from mutagen.id3 import ID3, TIT2, TALB, TPE1, APIC


def add_id3_tags_from_flac(flac_file):
    # 加载 FLAC 文件
    flac = FLAC(flac_file)

    # 创建 ID3 标签
    id3 = ID3()

    # 从 Vorbis 评论中提取标签
    title = flac.tags.get('TITLE', [''])[0] if 'TITLE' in flac.tags else ''
    album = flac.tags.get('ALBUM', [''])[0] if 'ALBUM' in flac.tags else ''
    artist = flac.tags.get('ARTIST', [''])[0] if 'ARTIST' in flac.tags else ''

    # 确保提取到的标签是字符串
    title = title if isinstance(title, str) else str(title[0]) if title else ''
    album = album if isinstance(album, str) else str(album[0]) if album else ''
    artist = artist if isinstance(artist, str) else str(artist[0]) if artist else ''

    # 设置 ID3 标签
    # id3.add(TIT2(encoding=3, text=title))  # 标题
    # id3.add(TALB(encoding=3, text=album))  # 专辑
    # id3.add(TPE1(encoding=3, text=artist))  # 艺术家

    # 添加封面图像（从 FLAC 中提取）
    if flac.pictures:
        for picture in flac.pictures:
            id3.add(APIC(
                encoding=3,
                mime=picture.mime,
                type=3,  # 封面图像
                desc='Cover',
                data=picture.data
            ))

    # 如果 FLAC 文件没有 ID3 标签，添加 ID3 标签

    #flac.add_tags()

    # 更新 ID3 标签
    flac.tags.update(id3)

    # 保存更新后的 FLAC 文件
    flac.save()


def main():
    folder_path = "/Users/swipher/Music/set/TEST"  # 替换为你的 FLAC 文件夹路径
    for file in os.listdir(folder_path):
        if file.endswith('.flac'):
            add_id3_tags_from_flac(os.path.join(folder_path, file))
            print(f"Added ID3 tags from {file}.")


if __name__ == "__main__":
    main()
